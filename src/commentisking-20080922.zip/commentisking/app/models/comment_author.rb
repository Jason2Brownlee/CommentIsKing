class CommentAuthor
  attr_accessor :name, :nickname, :profile_url, :image_url  
  
end