class Comment
  attr_accessor :title, :content, :author, :link, :date, :source_name
  
  
  
end