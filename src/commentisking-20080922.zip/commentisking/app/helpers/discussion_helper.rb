module DiscussionHelper
end
