class CreateSubmission1s < ActiveRecord::Migration
  def self.up
    create_table :submissions do |t|
      t.string :address

      t.timestamps
    end
  end

  def self.down
    drop_table :submission1s
  end
end
